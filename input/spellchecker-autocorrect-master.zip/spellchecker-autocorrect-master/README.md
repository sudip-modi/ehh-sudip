spellchecker-autocorrect
========================

Norvig inspired spellchecker and autocorrect implementation in javascript


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/WillSen/spellchecker-autocorrect/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

