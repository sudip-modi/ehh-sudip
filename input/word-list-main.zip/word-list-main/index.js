'use strict';
const path = require('path');

module.exports = path.join(__dirname, 'words.txt');
