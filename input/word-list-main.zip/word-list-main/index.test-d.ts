import {expectType} from 'tsd';
import wordListPath = require('.');

expectType<string>(wordListPath);
