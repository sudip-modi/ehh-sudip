interface Post {
    category: 'Basic' | 'Intermediate' |  'Advanced' | 'Tip';
    slug: string;
}

export default Post;
